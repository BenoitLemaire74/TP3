# PREDICAT
API pour classification des libellés de caisse

En lien avec l'application: https://github.com/InseeFrLab/product-labelling
